package com.wabu.d2project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class D2project3Application {
	public static void main(String[] args) {
		SpringApplication.run(D2project3Application.class, args);
	}	
}
