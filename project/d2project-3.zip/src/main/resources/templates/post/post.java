package templates.post;

public class post {

}
