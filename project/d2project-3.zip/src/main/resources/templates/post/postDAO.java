package templates.post;

public class postDAO {

}
