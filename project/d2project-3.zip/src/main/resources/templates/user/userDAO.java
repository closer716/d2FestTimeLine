package templates.user;

import org.springframework.stereotype.Repository;

@Repository
public class userDAO {

}
